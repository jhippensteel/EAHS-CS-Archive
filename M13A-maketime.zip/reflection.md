# Reflection on Make Time Project

## Relevance

*Answer the following questions in at least four total sentences.  What was your original claim as to why your project was relevant (check your proposal)?  Do you think you achieved the goal of producing something people can benefit from?  List two possible ways you could continue the project to make it more relevant.*

My original claim was as to why this project is relevant was *This project is important because is allows a user to be able to play the game mastermind without a second player. They can have fun with this game. People that are alone can play the game.* I think my project is something that people can benefit from. Two things I could do to make the project more relevant are to add a multiplayer capability and to add an AI that can guess the user's code.

## Demonstration

*Answer the following in at least three total sentences. Did you use the five items you originally intended, or did you need to make a change (describe the changes)?  Of the class skills you used, which one did this project strengthen the most for you?*

I used all five of the items I originally intended. I did however use them in different ways than I thought I would. Of the class skills I used, I think this project strengthened my understanding of If Statements the most.

## Extension

*Answer the following in at least thre total sentences.  What were the two (or more) brand new concepts you learned during the project?  How did you find out or learn about them?  Are any ones that you could see using in the future?*

Some concepts that I learned during the project were Operating System functions such as "os.system("clear")", while loops, for loops where the variable is in itself for example: "[c for c in range(1, 10)]", and lists. Some of them I had to look up on the internet, and some of the others I had to figure out through expirimentation, and a few of them I learned from Mr. Kindt or Ethan. I thinks I will use lists and while loops in the future.

## Function

*Answer the following in at least three total sentences. Is there anywhere you know your project isn't working right now (you won't lose points for telling me!)? What are some functions that you wish you would have had time to add onto the project?  If given the choice to continue this project OR take on a new project for part of your final exam grade in this course, which would you choose and why?*

My project *might* still have small problems with repeat numbers in the code or in the user's guess. There are no functions *that I know about* that I wish I could have added to my program. If I were given the choice to continue this project or start a new on for my final exam, I think I would try to improve this product because while I think I could still find a way to make my program better.

## Aesthetic

*Answer the following in at least three sentences.  What is the most difficult or annoying part of creating user-friendly and programmer-friendly programs?  Is it worth it?  What's the number one item on your wish list of features from Python to make your life easier in this area?*

The most annoying part of creating user-friendly and programmer-friendly is figuring out what the user or programmer wants to see in the software. I do think it is worth it though because the software looks nice when I was done. One thing I wish that was in python that would make my life easier is the ability to go inside strings and take variables out. such as .replace(variable1, "") after I concatenate variables.