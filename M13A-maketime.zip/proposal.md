***Edit this document with your own information to complete your proposal***

# Project Abstract 

###### *Write a two-sentence summary of what your project is about here. *
My project is going to be a mastermind computer game. The user will have to guess the code the computer has come up with.


# Project Details

## Relevance



###### Describe in detail why your project is important.  Be sure to classify it as productivity, entertainment, or education. 

Entertainment
- This project is important because is allows a user to be able to play the game *mastermind* without a second player. They can have fun with this game. People that are alone can play the game.
  - 

## Demonstration

Describe the five (**minimum**) concepts you learned in ITPP so far that you *plan* to use in the program.  That can't include anything from modules 1-3 (like print, or +, or input) or modules 6-7 (beautiful code/programs--that's judged in "aesthetics").  Select no more than two items per module of the course.
I plan to use:
- If statements
- Allignments
- For loops
- Termcolor
- Random Integers
- Input Handling

## Function

###### *Describe *exactly* what you want this program to be able to do.  I (Mr. Kindt) will collaborate with you to help you understand if it is an obtainable goal, point you towards new ideas that might help you solve it, and help you ensure you meet that goal (even if it means reducing or enlarging it).* :

I want this program to have three different levels: Novice, Expert, and *MasterMind*. I want this program to be able to randomly devise a 4 to 8 digit code. This program should be able to interpret the user's guess and output a key indicating how many digits they got correct, and how many they got correct in the right place using K's and W's. Then it should be able to understand when the user guesses the right code.I also want the user to be able to open a intsruction manual

--- 
--- 
---

# More
## about
### styling
#### in
##### markdown



<https://www.markdownguide.org/basic-syntax/>


